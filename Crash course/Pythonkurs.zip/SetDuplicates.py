def removeDup(liste):
    return list(set(liste))
